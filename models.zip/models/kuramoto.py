import os
from datetime import datetime
import tkinter as tk
from tkinter import messagebox
import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from utils.plots import plot_kuramoto_polar

def kuramoto_model(y, t, N, K, w):
    dydt = np.zeros(N)
    for i in range(N):
        dydt[i] = w[i] + K * np.sum(np.sin(y - y[i])) / N
    return dydt

def simulate_kuramoto(params):
    N = params["N"]
    # K = params["K"]
    t = np.arange(params["ti"], params["tf"], params["dt"])
    y0 = np.random.uniform(0.0, 2*np.pi, N)

    freq_type = params["freq_type"]
    fp = params["freq_params"]

    if freq_type == "uniform":
        w = np.random.uniform(fp["wmin"], fp["wmax"], N)
    elif freq_type == "gaussian":
        w = np.random.normal(fp["mean"], fp["std"], N)
    elif freq_type == "lorentzian":
        w = fp["mean"] + fp["gamma"] * np.tan(np.pi * (np.random.rand(N) - 0.5))

    Kmin = params["Kmin"]
    Kmax = params["Kmax"]
    dK = params["dK"]


    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    folder_name = f"data_{timestamp}"
    os.makedirs(folder_name, exist_ok=True)

    # Popup to inform
    root = tk.Tk()
    root.withdraw()
    messagebox.showinfo("Data Folder Created", f"All simulation data will be saved in:\n\n{folder_name}")

    print(Kmin, Kmax, dK)
    K_vals = np.arange(Kmin, Kmax + dK, dK)
    for K in K_vals:
        sol = odeint(kuramoto_model, y0, t, args=(N, K, w))

        filename = f"K_{K:.6f}.dat"

        filepath = os.path.join(folder_name, filename)
        
        np.savetxt(filepath, sol)
        print(f"\r K={np.round(K, 4)} is complete.")

        animation_option = params["anim_option"]
        # print(animation_option)
        animation_fps = params["fps_entry"]

        if animation_option == "show":
            plot_kuramoto_polar(sol, animation_fps, save=False, show=True)
        elif animation_option == "save_show":
            anim_folder_name = f"anim_{timestamp}"
            os.makedirs(anim_folder_name, exist_ok=True)
            animfilename = f"K_{K:.6f}.gif"
            anim_path = os.path.join(anim_folder_name, animfilename)
            plot_kuramoto_polar(sol, animation_fps, save=True, show=True, anim_path_prefix = anim_path)
        elif animation_option == "save":
            anim_folder_name = f"anim_{timestamp}"
            os.makedirs(anim_folder_name, exist_ok=True)
            animfilename = f"K_{K:.6f}.gif"
            anim_path = os.path.join(anim_folder_name, animfilename)
            plot_kuramoto_polar(sol, animation_fps, save=True, show=False, anim_path_prefix = anim_path)
        elif animation_option == "DoNotSave":
            pass
    
    messagebox.showinfo("Simulations Complete", f"All simulations finished.\n\nData saved in:\n{folder_name}")
    root.destroy()