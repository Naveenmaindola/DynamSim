import tkinter as tk
from tkinter import messagebox
from models.kuramoto import simulate_kuramoto


class KuramScreen:
    def __init__(self):
        self.root_kuram = tk.Tk()
        self.root_kuram.geometry("800x600")
        self.root_kuram.title("DynaSim - Kuramoto")

        self.entries = {}
        self.freq_entries = {}
        self.freq_labels = []
        self.coup_entries = {}
        self.coup_labels = []

        self.freq_option = tk.StringVar(self.root_kuram, value="uniform")
        self.coup_option = tk.StringVar(self.root_kuram, value="single")
        self.anim_option = tk.StringVar(self.root_kuram, value="show")
        self.anim_option.trace_add("write", lambda *args: self.update_anim_fields())



        self.build_model_params_frame()
        self.build_simulation_params_frame()
        self.build_animation_options_frame()

        tk.Button(self.root_kuram, text="Simulate", command=self.simulate).pack(pady=10)

        self.update_freq_fields()
        self.update_coup_fields()
        self.update_anim_fields() 

        self.root_kuram.mainloop()

    def build_model_params_frame(self):
        frame = tk.LabelFrame(self.root_kuram, text="Model Parameters", padx=10, pady=10)
        frame.pack(padx=10, pady=10, fill="x")

        # N
        tk.Label(frame, text="N:").grid(row=0, column=0, sticky="e")
        self.entries["N"] = tk.Entry(frame)
        self.entries["N"].grid(row=0, column=1, padx=10, pady=5)

        # Frequency Distribution
        tk.Label(frame, text="Frequency Distribution:").grid(row=1, column=0, sticky="e")
        freq_options = [("Uniform", "uniform"), ("Gaussian", "gaussian"), ("Lorentzian", "lorentzian"), ("UploadFile", "upload")]
        for i, (label, val) in enumerate(freq_options):
            tk.Radiobutton(frame, text=label, variable=self.freq_option, value=val,
                        command=self.update_freq_fields).grid(row=1, column=1 + i, sticky="w")

        self.freq_frame = tk.Frame(frame)
        self.freq_frame.grid(row=2, column=0, columnspan=4, pady=5)

        # Coupling Options
        tk.Label(frame, text="Coupling:").grid(row=3, column=0, sticky="e")
        coup_modes = [("Single", "single"), ("Sweep", "sweep")]
        for i, (text, val) in enumerate(coup_modes):
            tk.Radiobutton(frame, text=text, variable=self.coup_option, value=val,
                        command=self.update_coup_fields).grid(row=3, column=1 + i, sticky="w")

        self.coup_frame = tk.Frame(frame)
        self.coup_frame.grid(row=4, column=0, columnspan=4, pady=5)

        self.root_kuram.update_idletasks()



    def build_simulation_params_frame(self):
        frame = tk.LabelFrame(self.root_kuram, text="Simulation Parameters", padx=10, pady=10)
        frame.pack(padx=10, pady=10, fill="x")

        sim_fields = [("Initial time (ti)", 0), ("End time (tf)", 1), ("Time step (dt)", 2)]
        for label_text, row in sim_fields:
            tk.Label(frame, text=label_text + ":").grid(row=row, column=0, sticky="e")
            entry = tk.Entry(frame)
            entry.grid(row=row, column=1, padx=10, pady=5)
            self.entries[label_text] = entry

        # self.root_kuram.update_idletasks()

    def build_animation_options_frame(self):
        self.anim_frame = tk.LabelFrame(self.root_kuram, text="Animation Options", padx=10, pady=10)
        self.anim_frame.pack(padx=10, pady=10, fill="x")

        self.anim_radios = []
        self.anim_warning = tk.Label(self.anim_frame, fg="red")

        self.update_anim_fields()

    def update_anim_fields(self):
        for widget in self.anim_frame.winfo_children():
            widget.destroy()

        mode = self.coup_option.get()
        selected_anim = self.anim_option.get()

        if mode == "single":
            # self.anim_option.set("show")
            options = [("Show only", "show"), ("Save only", "save"), ("Save & Show", "save_show")]
            for i, (text, val) in enumerate(options):
                rb = tk.Radiobutton(self.anim_frame, text=text, variable=self.anim_option, value=val)
                rb.grid(row=0, column=i, padx=10, pady=5)
                self.anim_radios.append(rb)

            tk.Label(self.anim_frame, text="FPS:").grid(row=1, column=0, sticky="e")
            self.fps_entry = tk.Entry(self.anim_frame)
            self.fps_entry.grid(row=1, column=1, padx=10, pady=5)
            self.fps_entry.insert(0, "30")

        elif mode == "sweep":
            # self.anim_option.set("DoNotSave")
            options = [("Do Not Save", "DoNotSave"), ("save", "save")]

            for i, (text, val) in enumerate(options):
                rb = tk.Radiobutton(self.anim_frame, text=text, variable=self.anim_option, value=val)
                rb.grid(row=0, column=i, padx=10, pady=5)
                self.anim_radios.append(rb)

            if selected_anim == "save":
                tk.Label(self.anim_frame, text="FPS:").grid(row=2, column=0, sticky="e")
                self.anim_warning = tk.Label(self.anim_frame, text="⚠ Saving animations in sweep mode may take a long time.",
                                        fg="red")
                self.anim_warning.grid(row=1, column=0, columnspan=3)
                self.fps_entry = tk.Entry(self.anim_frame)
                self.fps_entry.grid(row=2, column=1, padx=10, pady=5)
                self.fps_entry.insert(0, "30")
            elif selected_anim == "DoNotSave":
                self.fps_entry = tk.Entry(self.anim_frame)
                self.fps_entry.insert(0, "30")



        # self.root_kuram.update_idletasks()

    def update_freq_fields(self):
        for widget in self.freq_frame.winfo_children():
            widget.destroy()
        self.freq_entries.clear()

        selected = self.freq_option.get()
        if selected == "uniform":
            fields = [("wmin", "wmin"), ("wmax", "wmax")]
        elif selected == "gaussian":
            fields = [("Mean (μ)", "mean"), ("Std Dev (σ)", "std")]
        elif selected == "lorentzian":
            fields = [("Mean (μ)", "mean"), ("Gamma (γ)", "gamma")]
        else:
            return

        for i, (label_text, key) in enumerate(fields):
            tk.Label(self.freq_frame, text=label_text + ":").grid(row=0, column=2*i, sticky="e")
            entry = tk.Entry(self.freq_frame)
            entry.grid(row=0, column=2*i+1, padx=10)
            self.freq_entries[key] = entry

        self.root_kuram.update_idletasks()

    def update_coup_fields(self):
        for widget in self.coup_frame.winfo_children():
            widget.destroy()
        self.coup_entries.clear()

        mode = self.coup_option.get()
        if mode == "single":
            fields = [("K", "K")]
        elif mode == "sweep":
            fields = [("Kmin", "Kmin"), ("Kmax", "Kmax"), ("dK", "dK")]
        else:
            return

        for i, (label_text, key) in enumerate(fields):
            tk.Label(self.coup_frame, text=label_text + ":").grid(row=0, column=2*i, sticky="e")
            entry = tk.Entry(self.coup_frame)
            entry.grid(row=0, column=2*i + 1, padx=10)
            self.coup_entries[key] = entry

        self.root_kuram.update_idletasks()
        self.update_anim_fields()

    def simulate(self):
        try:
            params = {
                "N": int(self.entries["N"].get()),
                "ti": float(self.entries["Initial time (ti)"].get()),
                "tf": float(self.entries["End time (tf)"].get()),
                "dt": float(self.entries["Time step (dt)"].get()),
                "anim_option": self.anim_option.get(),
                "fps_entry": int(self.fps_entry.get())
            }

            coup_mode = self.coup_option.get()
            params["K_mode"] = coup_mode
            if coup_mode == "single":
                K = float(self.coup_entries["K"].get())
                params["Kmin"] = K
                params["Kmax"] = K
                params["dK"] = 10  # Dummy large number
            else:  # sweep
                params["Kmin"] = float(self.coup_entries["Kmin"].get())
                params["Kmax"] = float(self.coup_entries["Kmax"].get())
                params["dK"] = float(self.coup_entries["dK"].get())

            freq_type = self.freq_option.get()
            params["freq_type"] = freq_type
            if freq_type == "uniform":
                params["freq_params"] = {
                    "wmin": float(self.freq_entries["wmin"].get()),
                    "wmax": float(self.freq_entries["wmax"].get())
                }
            elif freq_type == "gaussian":
                params["freq_params"] = {
                    "mean": float(self.freq_entries["mean"].get()),
                    "std": float(self.freq_entries["std"].get())
                }
            elif freq_type == "lorentzian":
                params["freq_params"] = {
                    "mean": float(self.freq_entries["mean"].get()),
                    "gamma": float(self.freq_entries["gamma"].get())
                }

            # Disclaimer for saving the animation while sweeping through K
            if coup_mode == "sweep":
                params["Kmin"] = float(self.coup_entries["Kmin"].get())
                params["Kmax"] = float(self.coup_entries["Kmax"].get())
                params["dK"] = float(self.coup_entries["dK"].get())

                if self.anim_option.get() == "save":
                    k_steps = int((params["Kmax"] - params["Kmin"]) / params["dK"]) + 1
                    proceed = messagebox.askyesno(
                        "Warning",
                        f"You are about to generate and save animations for {k_steps} coupling values.\n"
                        "This may take a significantly long time and space.\n\nProceed anyway?"
                    )
                    if not proceed:
                        return


            simulate_kuramoto(params)
            messagebox.showinfo("Success", "Simulation complete!")

        except ValueError as e:
            messagebox.showerror("Input Error", f"Invalid number format: {e}")
        except Exception as e:
            messagebox.showerror("Error", f"Unexpected error:\n{e}")
