import tkinter as tk
from gui.kuramoto_gui import KuramScreen
# from gui.stuart_landau_gui import StuartLandauScreen

class MyGui:
    all_models = ["Kuramoto", "Stuart Landau"]

    def __init__(self):
        
        self.root = tk.Tk()
        self.root.geometry("400x400")
        self.root.title("DynaSym-Lets Simulate")

        self.modelsframe = tk.Frame(self.root)
        self.modelsframe.columnconfigure(0, weight=1)
        self.modelsframe.columnconfigure(1, weight=1)

        

        self.check_state_m1 = tk.IntVar()
        self.check_state_m2 = tk.IntVar()

        tk.Label(self.modelsframe, text=self.all_models[0], font=("Helvetica", 15)).grid(row=0, column=0, sticky="NEWS", padx=10)
        tk.Checkbutton(self.modelsframe, variable=self.check_state_m1).grid(row=0, column=1)

        tk.Label(self.modelsframe, text=self.all_models[1], font=("Helvetica", 15)).grid(row=1, column=0, sticky="NEWS", padx=10)
        tk.Checkbutton(self.modelsframe, variable=self.check_state_m2).grid(row=1, column=1)

        self.modelsframe.pack(padx=15, pady=15)

        tk.Button(self.root, text="Enter", font=("Arial", 15), command=self.chosen_model).pack(padx=10, pady=10)

        self.root.mainloop()

    def chosen_model(self):
        if self.check_state_m1.get():
            KuramScreen()
        if self.check_state_m2.get():
            StuartLandauScreen()
