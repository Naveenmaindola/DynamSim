import matplotlib.pyplot as plt
import matplotlib.animation as animation
import numpy as np

def plot_kuramoto_polar(sol, animation_fps, save=False, show=False, anim_path_prefix = ""):
    N = sol.shape[1]
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='polar')
    ax.set_ylim(0.0, 1.25)
    line, = ax.plot(sol[0, :], np.ones(N), "mo", ms=8)

    def animate(i):
        line.set_xdata(sol[i, :])
        return line,

    anim = animation.FuncAnimation(fig, animate, np.arange(1, sol.shape[0]), interval=50, blit=True, repeat=False)
    print(animation_fps)
    if save:
        anim.save(f"{anim_path_prefix}", fps=animation_fps)
    if show:
        plt.show()
    else:
        plt.close(fig)
